from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import Order, OrderItem, OrderItemOption, OrderStatus
from app.schemas import OrderItemOptionResponse, OrderItemResponse, OrderListResponse, OrderStatusUpdate
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/kitchen", tags=["kitchen"])


def _order_to_list_response(order: Order) -> OrderListResponse:
    """Build OrderListResponse with item options (label, price_delta) for kitchen display."""
    items_data = []
    for item in order.items:
        options_data = []
        for oio in item.options:
            opt = oio.menu_item_option
            options_data.append(
                OrderItemOptionResponse(
                    id=oio.id,
                    menu_item_option_id=oio.menu_item_option_id,
                    label=opt.label if opt else None,
                    price_delta=opt.price_delta if opt else None,
                )
            )
        items_data.append(
            OrderItemResponse(
                id=item.id,
                menu_item_id=item.menu_item_id,
                name=item.name,
                unit_price=item.unit_price,
                quantity=item.quantity,
                notes=item.notes,
                options=options_data,
            )
        )
    return OrderListResponse(
        id=order.id,
        restaurant_id=order.restaurant_id,
        room_id=order.room_id,
        party_size=order.party_size,
        payment_method=order.payment_method,
        status=order.status,
        subtotal=order.subtotal,
        notes=order.notes,
        created_at=order.created_at,
        items=items_data,
    )


def _load_order_with_options(q):
    return q.options(
        selectinload(Order.items).selectinload(OrderItem.options).selectinload(OrderItemOption.menu_item_option)
    )


@router.get("/orders", response_model=list[OrderListResponse])
async def list_kitchen_orders(
    restaurant_id: UUID = Query(..., description="Filter by restaurant"),
    db: AsyncSession = Depends(get_db),
) -> list[OrderListResponse]:
    q = (
        select(Order)
        .where(Order.restaurant_id == restaurant_id)
        .where(Order.status != OrderStatus.cancelled)
        .order_by(Order.created_at.desc())
    )
    q = _load_order_with_options(q)
    result = await db.execute(q)
    orders = list(result.scalars().all())
    return [_order_to_list_response(o) for o in orders]


@router.patch("/orders/{order_id}", response_model=OrderListResponse)
async def update_order_status(
    order_id: UUID,
    body: OrderStatusUpdate,
    db: AsyncSession = Depends(get_db),
) -> OrderListResponse:
    result = await db.execute(
        _load_order_with_options(select(Order).where(Order.id == order_id))
    )
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    order.status = body.status
    await db.flush()
    await db.refresh(order)
    result2 = await db.execute(
        _load_order_with_options(select(Order).where(Order.id == order_id))
    )
    order = result2.scalar_one()
    return _order_to_list_response(order)
